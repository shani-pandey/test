import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactMeComponent } from './contact-me/contact-me.component';
import { HistoryComponent } from './history/history.component';
import { ShaniContentComponent } from './shani-content/shani-content.component';

const routes: Routes = [
  {path:'',redirectTo:'home', pathMatch: 'full' },
  { path: 'history', component: HistoryComponent },
  { path: 'home', component: ShaniContentComponent },
  { path: 'contact', component: ContactMeComponent },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
