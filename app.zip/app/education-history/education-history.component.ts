import { Component, OnInit } from '@angular/core';

import educationData from '../educationData.json';

interface Education {
  orgName : string;
  duration : any;
  desc : any;
}

@Component({
  selector: 'app-education-history',
  templateUrl: './education-history.component.html',
  styleUrls: ['./education-history.component.css']
})
export class EducationHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  education : Education [] = educationData;

}
