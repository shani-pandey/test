import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShaniInfoComponent } from './shani-info/shani-info.component';
import { ShaniMenuComponent } from './shani-menu/shani-menu.component';
import { ShaniContentComponent } from './shani-content/shani-content.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { FormsModule } from '@angular/forms';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { ServiceComponent } from './service/service.component';
import { HistoryComponent } from './history/history.component';

import { WorkHistoryComponent } from './work-history/work-history.component';
import { EducationHistoryComponent } from './education-history/education-history.component';
import { ContactMeComponent } from './contact-me/contact-me.component';
import { ContactFormComponent } from './contact-form/contact-form.component';




@NgModule({
  declarations: [
    AppComponent,
    ShaniInfoComponent,
    ShaniMenuComponent,
    ShaniContentComponent,
    ServiceComponent,
    HistoryComponent,
    WorkHistoryComponent,
    EducationHistoryComponent,
    ContactMeComponent,
    ContactFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatProgressBarModule,
    FormsModule,MatProgressSpinnerModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
