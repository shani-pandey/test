import { Component, OnInit } from '@angular/core';
 


@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
  form : any;

  constructor() { }

  ngOnInit(): void {
  }


  myCform(value:any){
     
    
    alert(`Name: ${value.name},   Email: ${value.email}, Message: ${value.message}`);
    
   
    
  }

}
