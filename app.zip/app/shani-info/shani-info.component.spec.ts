import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShaniInfoComponent } from './shani-info.component';

describe('ShaniInfoComponent', () => {
  let component: ShaniInfoComponent;
  let fixture: ComponentFixture<ShaniInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShaniInfoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShaniInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
