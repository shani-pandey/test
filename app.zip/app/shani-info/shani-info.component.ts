import { Component, OnInit } from '@angular/core';
import { timer } from 'rxjs';

@Component({
  selector: 'app-shani-info',
  templateUrl: './shani-info.component.html',
  styleUrls: ['./shani-info.component.css']
})
export class ShaniInfoComponent implements OnInit {

  value: number = 0;
  html: number = 0;
  css: number = 0;
  js: number = 0;
  ang: number = 0;
  cms: number = 0;
  eng =0;
  hindi=0;
  hing =0;



  constructor() {

    const source =timer(1000,20);
    const suscribe = source.subscribe(val=>{
      this.html = 90;
      this.css = 90;
      this.js = 70;
      this.ang = 70;
      this.cms = 55;
      this.eng = 80;
      this.hindi = 95;
      this.hing = 95;
    })
   }

  ngOnInit(): void {



     
  }



}
