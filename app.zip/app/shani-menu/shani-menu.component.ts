import { Component, OnInit } from '@angular/core';
 

@Component({
  selector: 'app-shani-menu',
  templateUrl: './shani-menu.component.html',
  styleUrls: ['./shani-menu.component.css']
})
export class ShaniMenuComponent implements OnInit {

  menuOpen : boolean  = false;
  iconCross : boolean = false;
  iconBar :boolean = true;
  currentMenu : boolean =true
  activeMenu:any;

  constructor( ) { 
    
    
}



  ngOnInit(): void {

    let curUrl=( window.location.pathname);
     
    this.activeMenu = curUrl.slice(1)
    
  }

  activem():void{
    let curUrl=( window.location.pathname);
     
    this.activeMenu = curUrl.slice(1)
			 
    

  }



  menuOn():void{

    if (this.iconBar == true){
        this.menuOpen = true;
        this.iconCross = true;
        this.iconBar = false;

        let element: any | undefined|null
        element = document.querySelector(".app-content");
        element.classList.add("menu-active");

        let menuBlock: any | undefined|null = document.querySelector(".menu-block-area");
        
        menuBlock.classList.add("menu-block-incr");

        this.currentMenu = false;

        
    
    }
    else{
        this.menuOpen = false;
        this.iconCross = false;
        this.iconBar = true;

        let element: any | undefined| null
        element = document.querySelector(".app-content");
        element.classList.remove("menu-active");


        let menuBlock: any | undefined|null = document.querySelector(".menu-block-area");
        
        menuBlock.classList.remove("menu-block-incr");

        this.currentMenu = true;
    
    }
    
  }

 

    
 

 

}
