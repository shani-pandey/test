import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShaniMenuComponent } from './shani-menu.component';

describe('ShaniMenuComponent', () => {
  let component: ShaniMenuComponent;
  let fixture: ComponentFixture<ShaniMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShaniMenuComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShaniMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
