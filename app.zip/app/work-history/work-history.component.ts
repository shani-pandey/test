import { Component, OnInit } from '@angular/core';
import wordData from '../workData.json';

interface workData {
  companyName:string
  duration:any
  desc:any
}

@Component({
  selector: 'app-work-history',
  templateUrl: './work-history.component.html',
  styleUrls: ['./work-history.component.css']
})
export class WorkHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  workData : workData[] = wordData;
}
