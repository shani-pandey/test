import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShaniContentComponent } from './shani-content.component';

describe('ShaniContentComponent', () => {
  let component: ShaniContentComponent;
  let fixture: ComponentFixture<ShaniContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShaniContentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShaniContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
