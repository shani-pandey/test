import { Component, OnInit } from '@angular/core';
import { timer } from 'rxjs';

@Component({
  selector: 'app-shani-content',
  templateUrl: './shani-content.component.html',
  styleUrls: ['./shani-content.component.css']
})
export class ShaniContentComponent implements OnInit {

 currentYear:number =0;

  constructor() { 
   
  
  }

  ngOnInit(): void {

    const counters = document.querySelectorAll(".counter");
    console.log(counters);
    
    counters.forEach((counter:any)=>{
      counter.innerHTML = 0;
      const updateCounter = ()=>{
        const target :number = +counter.getAttribute("data-count");
        
        
        const startNumber :number = +counter.innerHTML ;
        
        const incr: number = Math.floor(target/2);
        
        if (startNumber < target) {
          counter.innerHTML = `${startNumber + incr}`;
 
       

          
         
          
          setTimeout (updateCounter,500)
        }
        else{
          counter.innerHTML = target;
        }
      
      }

      updateCounter();

    });

    // get current year for copyright section

    const d =  new Date();

    this.currentYear = d.getFullYear();
   
    

  }




  

}


